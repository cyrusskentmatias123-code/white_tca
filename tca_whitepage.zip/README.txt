tca_whitepage — quick package
Files:
  - index.html     (ready-to-host)
  - IMG_1773.jpeg  (thumbnail image)

Quick notes:
  - This page is intentionally blank/white in the browser.
  - The image is included and referenced by the Open Graph meta tags so social platforms
    will use it as the link preview thumbnail.

Hosting options (brief):
1) Netlify (easiest)
   - Unzip this package.
   - Go to https://app.netlify.com/drop (or Netlify Dashboard -> Sites -> Add new site -> Drag & drop).
   - Drag the unzipped folder. Netlify will deploy and give a public URL.
   - If preview doesn't show immediately, open Netlify site URL, then (optional) update index.html to set og:image to the full absolute URL:
       https://your-netlify-domain/IMG_1773.jpeg
     then redeploy.

2) GitHub Pages (stable)
   - Create a GitHub account (if you don't have one).
   - Create a new public repository (e.g., tca-whitepage).
   - Upload index.html and IMG_1773.jpeg (Add file -> Upload files) and commit.
   - In repository: Settings -> Pages -> Choose branch: main (root) -> Save.
   - Your site will be at: https://<your-github-username>.github.io/<repo-name>/
   - Edit index.html in the repo to replace og:image with:
       https://<your-github-username>.github.io/<repo-name>/IMG_1773.jpeg
     Commit; wait a minute. Share the repo URL.

3) Vercel (also easy; supports drag & drop or Git import)
   - Similar: deploy the folder or connect a Git repo, then update og:image to absolute URL if needed.

Troubleshooting:
  - Social platforms cache previews. Use platform debuggers to refresh:
    - Facebook Sharing Debugger, Twitter Card Validator, etc.
  - For best appearance use a large image (1200x630 or similar). Small images might not generate large previews.
  - If you want a custom domain, set it in the host (Netlify/GitHub Pages/Vercel) and then use that domain in og:url and og:image.

That's it — unzip and deploy the folder on any static host.

